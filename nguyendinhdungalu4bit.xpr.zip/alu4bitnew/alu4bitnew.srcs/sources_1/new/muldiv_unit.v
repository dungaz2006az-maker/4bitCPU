`timescale 1ns / 1ps
module muldiv_unit(
    input clk,
    input rst,
    input start,
    input [3:0] a,
    input [3:0] b,
    input is_div,
    input is_muldiv,
    output reg [7:0] hi_lo,
    output reg busy,
    output reg done,
    output reg div_by_zero
);
    reg [2:0] counter;

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            hi_lo <= 8'd0;
            busy <= 1'b0;
            done <= 1'b0;
            div_by_zero <= 1'b0;
            counter <= 3'd0;
        end else begin
            done <= 1'b0;
            if (start && is_muldiv) begin
                busy <= 1'b1;
                counter <= 3'd5;
                if (is_div) begin
                    if (b == 4'd0) begin
                        div_by_zero <= 1'b1;
                        hi_lo <= 8'd0;
                    end else begin
                        hi_lo <= {4'd0, a / b};
                    end
                end else begin
                    hi_lo <= a * b;
                end
            end else if (busy) begin
                if (counter > 3'd1) begin
                    counter <= counter - 1'b1;
                end else begin
                    busy <= 1'b0;
                    done <= 1'b1;
                end
            end
        end
    end
endmodule