`timescale 1ns / 1ps
module adder_subtracter_4bit(
    input [3:0] a,
    input [3:0] b,
    input sub,
    output [3:0] result,
    output c4,
    output c3,
    output overflow
);
    wire [3:0] b_xor = b ^ {4{sub}};
    wire c1, c2;

    full_adder fa0 (.a(a[0]), .b(b_xor[0]), .cin(sub),   .sum(result[0]), .cout(c1));
    full_adder fa1 (.a(a[1]), .b(b_xor[1]), .cin(c1),    .sum(result[1]), .cout(c2));
    full_adder fa2 (.a(a[2]), .b(b_xor[2]), .cin(c2),    .sum(result[2]), .cout(c3));
    full_adder fa3 (.a(a[3]), .b(b_xor[3]), .cin(c3),    .sum(result[3]), .cout(c4));

    assign overflow = c3 ^ c4;
endmodule