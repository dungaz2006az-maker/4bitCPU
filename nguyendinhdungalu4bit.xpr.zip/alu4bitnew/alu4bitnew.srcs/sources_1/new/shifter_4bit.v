`timescale 1ns / 1ps
module shifter_4bit(
    input [3:0] a,
    input is_shl,
    input is_shr,
    output reg [3:0] result,
    output reg out_bit
);
    always @(*) begin
        if (is_shl) begin
            result = {a[2:0], 1'b0};
            out_bit = a[3];
        end else if (is_shr) begin
            result = {1'b0, a[3:1]};
            out_bit = a[0];
        end else begin
            result = a;
            out_bit = 1'b0;
        end
    end
endmodule