`timescale 1ns / 1ps
module logic_unit_4bit(
    input [3:0] a,
    input [3:0] b,
    input [3:0] opcode,
    output reg [3:0] result
);
    always @(*) begin
        case(opcode)
            4'b0010: result = a & b;   // AND
            4'b0011: result = a | b;   // OR
            4'b0100: result = a ^ b;   // XOR
            4'b0101: result = ~a;      // NOT A
            default: result = 4'b0000;
        endcase
    end
endmodule