`timescale 1ns / 1ps
module control_unit(
    input [3:0] opcode,
    output sub,
    output arith,
    output is_shl,
    output is_shr,
    output is_div,
    output is_muldiv
);
    assign sub     = (opcode == 4'b0001);
    assign arith   = (opcode[3:1] == 3'b000); // 0000 (ADD) or 0001 (SUB)
    assign is_shl  = (opcode == 4'b0110);
    assign is_shr  = (opcode == 4'b0111);
    assign is_div  = (opcode == 4'b1001);
    assign is_muldiv = (opcode[3:1] == 3'b100); // 100x (MUL or DIV)
endmodule