`timescale 1ns / 1ps
module flag_unit(
    input arith,
    input is_shl,
    input is_shr,
    input c4,
    input overflow_in,
    input [3:0] result,
    input shl_bit,
    input shr_bit,
    output carry,
    output zero,
    output overflow,
    output negative
);
    assign zero = (result == 4'b0000);
    assign negative = result[3];
    assign overflow = arith ? overflow_in : 1'b0;
    assign carry = (arith & c4) | (is_shl & shl_bit) | (is_shr & shr_bit);
endmodule
