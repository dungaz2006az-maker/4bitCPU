`timescale 1ns / 1ps
module alu_4bit(
    input clk,
    input rst,
    input start,
    input [3:0] a,
    input [3:0] b,
    input [3:0] opcode,
    output [7:0] result,
    output carry,
    output zero,
    output overflow,
    output negative,
    output busy,
    output done,
    output div_by_zero
);
    wire sub, arith, is_shl, is_shr, is_div, is_muldiv;
    wire [3:0] sum_res, logic_res, shift_res;
    wire c4, c3, ovf_adder, shl_out;
    wire [7:0] muldiv_res;

    control_unit cu (
        .opcode(opcode), .sub(sub), .arith(arith),
        .is_shl(is_shl), .is_shr(is_shr), .is_div(is_div), .is_muldiv(is_muldiv)
    );

    adder_subtracter_4bit add_sub (
        .a(a), .b(b), .sub(sub), .result(sum_res),
        .c4(c4), .c3(c3), .overflow(ovf_adder)
    );

    logic_unit_4bit lu (
        .a(a), .b(b), .opcode(opcode), .result(logic_res)
    );

    shifter_4bit shifter (
        .a(a), .is_shl(is_shl), .is_shr(is_shr),
        .result(shift_res), .out_bit(shl_out)
    );

    muldiv_unit md (
        .clk(clk), .rst(rst), .start(start), .a(a), .b(b),
        .is_div(is_div), .is_muldiv(is_muldiv),
        .hi_lo(muldiv_res), .busy(busy), .done(done), .div_by_zero(div_by_zero)
    );

    result_mux r_mux (
        .opcode(opcode), .sum_result(sum_res), .logic_result(logic_res),
        .shift_result(shift_res), .muldiv_result(muldiv_res), .result(result)
    );

    flag_unit flags (
        .arith(arith), .is_shl(is_shl), .is_shr(is_shr),
        .c4(c4), .overflow_in(ovf_adder), .result(result[3:0]),
        .shl_bit(shl_out), .shr_bit(shl_out),
        .carry(carry), .zero(zero), .overflow(overflow), .negative(negative)
    );

endmodule