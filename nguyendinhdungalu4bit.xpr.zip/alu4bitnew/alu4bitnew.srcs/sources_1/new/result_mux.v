`timescale 1ns / 1ps
module result_mux(
    input [3:0] opcode,
    input [3:0] sum_result,
    input [3:0] logic_result,
    input [3:0] shift_result,
    input [7:0] muldiv_result,
    output reg [7:0] result
);
    always @(*) begin
        casex (opcode)
            4'b000x: result = {4'd0, sum_result};   // ADD, SUB
            4'b0010, 
            4'b0011, 
            4'b0100, 
            4'b0101: result = {4'd0, logic_result}; // Logic (AND, OR, XOR, NOT)
            4'b0110, 
            4'b0111: result = {4'd0, shift_result}; // SHL, SHR
            4'b100x: result = muldiv_result;        // MUL, DIV
            default: result = 8'd0;
        endcase
    end
endmodule