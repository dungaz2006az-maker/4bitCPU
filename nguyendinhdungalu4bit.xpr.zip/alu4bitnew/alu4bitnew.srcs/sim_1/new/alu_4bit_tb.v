`timescale 1ns / 1ps
module alu_4bit_tb;
    reg clk, rst, start;
    reg [3:0] a, b, opcode;
    wire [7:0] result;
    wire carry, zero, overflow, negative, busy, done, div_by_zero;

    reg [7:0] exp_res_global;
    integer errors = 0;
    integer total_checks = 0;

    alu_4bit uut (
        .clk(clk), .rst(rst), .start(start), .a(a), .b(b), .opcode(opcode),
        .result(result), .carry(carry), .zero(zero), .overflow(overflow),
        .negative(negative), .busy(busy), .done(done), .div_by_zero(div_by_zero)
    );

    always #5 clk = ~clk;

    initial begin
        clk = 0; rst = 1; start = 0; a = 0; b = 0; opcode = 0;
        exp_res_global = 8'd0;
        #20; rst = 0; #10;

        $display("\n========================================================");
        $display("   STUDENT NAME : Nguyen Dinh Dung");
        $display("   ROLL NUMBER  : HE201882");
        $display("   PROJECT      : 4-bit ALU Design and Simulation");
        $display("========================================================");

        // --- PART 1: Single-cycle Operations (Arithmetic, Logic & Shift) ---
        $display("\n--- PART 1: Single-Cycle Tests ---");
        run_single_cycle_test(4'b0000, 4'd5,  4'd3,  8'd8);   // ADD: 5 + 3 = 8
        run_single_cycle_test(4'b0001, 4'd7,  4'd4,  8'd3);   // SUB: 7 - 4 = 3
        run_single_cycle_test(4'b0010, 4'd12, 4'd10, 8'd8);   // AND: 12 & 10 = 8
        run_single_cycle_test(4'b0011, 4'd12, 4'd10, 8'd14);  // OR:  12 | 10 = 14
        run_single_cycle_test(4'b0100, 4'd12, 4'd10, 8'd6);   // XOR: 12 ^ 10 = 6
        run_single_cycle_test(4'b0110, 4'd11, 4'd0,  8'd6);   // SHL: 11 << 1 = 6

        // --- PART 2: Multi-cycle Operations (Multiplier & Divider) ---
        $display("\n--- PART 2: Multi-Cycle Tests (Mul / Div) ---");
        run_mul_div_test(4'b1000, 4'd13, 4'd11, 8'd143); // MUL: 13 * 11 = 143
        run_mul_div_test(4'b1001, 4'd12, 4'd4,  8'd3);   // DIV: 12 / 4 = 3

        $display("--------------------------------------------------------");
        if (errors == 0) begin
            $display("PASS: Tat ca %0d bai kiem tra da hoan tat, 0 loi!", total_checks);
        end else begin
            $display("FAIL: Phat hien %0d loi tren tong so %0d kiem tra.", errors, total_checks);
        end
        $display("========================================================\n");
        $finish;
    end

    task run_single_cycle_test(
        input [3:0] op,
        input [3:0] op_a,
        input [3:0] op_b,
        input [7:0] exp_res
    );
        begin
            opcode = op;
            a = op_a;
            b = op_b;
            exp_res_global = exp_res;
            
            #10;
            total_checks = total_checks + 1;
            
            if (result !== exp_res) begin
                $display("ERROR | Op: %b | A: %0d | B: %0d | Got: %0d (Exp: %0d)", op, op_a, op_b, result, exp_res);
                errors = errors + 1;
            end else begin
                $display("PASS  | Op: %b | A: %0d | B: %0d | Result: %0d matched", op, op_a, op_b, result);
            end
        end
    endtask

    task run_mul_div_test(
        input [3:0] op,
        input [3:0] op_a,
        input [3:0] op_b,
        input [7:0] exp_res
    );
        begin
            opcode = op;
            a = op_a;
            b = op_b;
            exp_res_global = exp_res;
            start = 1;
            #10;
            start = 0;
            
            @(posedge done);
            #5;
            total_checks = total_checks + 1;
            
            if (result !== exp_res) begin
                $display("ERROR | MUL/DIV Op: %b | A: %0d | B: %0d | Got: %0d (Exp: %0d)", op, op_a, op_b, result, exp_res);
                errors = errors + 1;
            end else begin
                $display("PASS  | MUL/DIV Op: %b | A: %0d | B: %0d | Result: %0d matched", op, op_a, op_b, result);
            end
        end
    endtask

endmodule